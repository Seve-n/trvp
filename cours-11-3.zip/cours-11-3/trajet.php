<?php
// trajet.php
header('Content-Type: application/json');
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getConnection();

switch ($method) {
    case 'GET':
        $stmt = $conn->query("SELECT * FROM trajet");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $sql = "INSERT INTO trajet (id_vehicule, depart, destination, date_heure, prix) VALUES (:id_vehicule, :depart, :destination, :date_heure, :prix)";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
        echo json_encode(['message' => 'Trajet créé avec succès']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Méthode non autorisée']);
}
?>
