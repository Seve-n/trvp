<?php
// db.php
define('USER', 'scott');
define('PASSWD', 'tiger');
define('SERVER', 'localhost');
define('BASE', 'ebus2');

function getConnection() {
    try {
        $dsn = 'mysql:host=' . SERVER . ';dbname=' . BASE;
        $connexion = new PDO($dsn, USER, PASSWD);
        $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $connexion;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Échec de la connexion : ' . $e->getMessage()]);
        exit();
    }
}
?>
