<?php
// vehicule.php
header('Content-Type: application/json');
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getConnection();

switch ($method) {
    case 'GET':
        $stmt = $conn->query("SELECT * FROM vehicule");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $sql = "INSERT INTO vehicule (id_utilisateur, marque, modele, immatriculation, nombre_de_places) VALUES (:id_utilisateur, :marque, :modele, :immatriculation, :nombre_de_places)";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
        echo json_encode(['message' => 'Véhicule créé avec succès']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Méthode non autorisée']);
}
?>
