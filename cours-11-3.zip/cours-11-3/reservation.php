<?php
// reservation.php
header('Content-Type: application/json');
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getConnection();

switch ($method) {
    case 'GET':
        $stmt = $conn->query("SELECT * FROM reservation");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $sql = "INSERT INTO reservation (id_trajet, id_passager, statut, comment, date) VALUES (:id_trajet, :id_passager, :statut, :comment, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
        echo json_encode(['message' => 'Réservation créée avec succès']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Méthode non autorisée']);
}
?>
