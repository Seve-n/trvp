<?php
// utilisateur.php
header('Content-Type: application/json');
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$conn = getConnection();

switch ($method) {
    case 'GET':
        $stmt = $conn->query("SELECT * FROM utilisateur");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $sql = "INSERT INTO utilisateur (nom, prenom, email, mot_de_passe, telephone) VALUES (:nom, :prenom, :email, :mot_de_passe, :telephone)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':nom' => $data['nom'],
            ':prenom' => $data['prenom'],
            ':email' => $data['email'],
            ':mot_de_passe' => password_hash($data['mot_de_passe'], PASSWORD_BCRYPT),
            ':telephone' => $data['telephone']
        ]);
        echo json_encode(['message' => 'Utilisateur créé avec succès']);
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Méthode non autorisée']);
}
?>
