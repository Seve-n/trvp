<?php
define('USER','co90od46edee');
define('PASSWD','c2.d7e_5io');
define('SERVER','localhost');
define('BASE','ebus2_projet07_reir98');
?>
