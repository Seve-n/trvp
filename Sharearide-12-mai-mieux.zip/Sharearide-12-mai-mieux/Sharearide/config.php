<?php
// Définir les constantes pour la connexion à la base de données
define('USER', 'ebus2');
define('PASSWD', '2AT5z-62B4.QSr');
define('SERVER', 'localhost');
define('BASE', 'ebus2bdapps');
<?