# Sharearide
Projet d'application web réalisé dans le cadre du cours de Bases de données et applications Web

## 👤 Réalisé par
Mathis Léonard

## 🧠 Objectif du projet
Créer une application simple de covoiturage permettant :
- Aux utilisateurs de proposer un trajet
- Aux passagers de réserver une place

## 🛠️ Technologies utilisées
- HTML / CSS / JavaScript (interface)
- PHP (logique serveur, sessions)
- JSON (échange de données)
- MySQL (base de données)
  
## ✅ Fonctionnalités
- Connexion / déconnexion avec sessions PHP
- Ajout et consultation de trajets
- Réservation avec stockage dans un fichier JSON

